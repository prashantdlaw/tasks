const express = require('express');
const contactRouter = require('./contact')
const app = express();
const port = 3000;

app.use('/contact', contactRouter)


app.listen(port, '0.0.0.0', () => {
    console.log(`Server started at ${port}`)
})