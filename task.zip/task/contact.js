const express = require('express')
const db = require('./db')
const router = express.Router()

// -------------------------
// GET
// -------------------------
router.get('/all/:page_no', async (req, res) => {
    try {
        const page_no = req.params.page_no;
        const off_set = (page_no - 1) * 2;

        const [contact] = await db.query(`select * from contact order by contact_name asc limit 2 offset ${off_set} `)
        if (contact.length > 0) {
            return res.json({
                code: "1000",
                status: "Response Successfully Complete",
                contact: contact
            })
        } else {
            return res.json({
                code: "1001",
                status: "Data Not Found",
            })
        }
    } catch (err) {
        console.log(err)
    }

})

router.get('/single/:contact_id', async (req, res) => {
    try {
        const contact_id = req.params.contact_id

        const [contact] = await db.query(`select * from contact where contact_id = ${contact_id}`)
        if (contact.length > 0) {
            return res.json({
                code: "1000",
                status: "Response Successfully Complete",
                contact: contact[0]
            })
        } else {
            return res.json({
                code: "1001",
                status: "Data Not Found",
            })
        }
    } catch (err) {
        console.log(err)
    }

})

router.get('/search/:parm', async (req, res) => {
    try {
        const parm = req.params.parm
        
        const [contact] = await db.query(`select * from contact where contact_name like '%${parm}%' order by contact_name asc`)
        if (contact.length > 0) {
            return res.json({
                code: "1000",
                status: "Response Successfully Complete",
                contact: contact
            })
        } else {
            return res.json({
                code: "1001",
                status: "Data Not Found",
            })
        }
    } catch (err) {
        console.log(err)
    }

})

router.delete('/delete/:contact_id', async (req, res) => {
    try {
        const contact_id = req.params.contact_id

        const [contact] = await db.query(`select * from contact where contact_id = ${contact_id} `)
        if (contact.length > 0) {
            const [remove] = await db.query(`delete from contact where contact_id = ${contact_id}`)
            if (remove.affectedRows > 0) {
                return res.json({
                    code: "1000",
                    status: "Contact Deleted Successfully",
                    contact: contact
                })
            } else {
                return res.json({
                    code: "1001",
                    status: "Contact Deleted",

                })
            }
        } else {
            return res.json({
                code: "1001",
                status: "Data Not Found",

            })
        }

    } catch (err) {
        console.log(err)
    }

})


module.exports = router